package com.example.spacemissions;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    int count = 0;
    MyDatabaseHelper myDB;
    public static final String TABLE_NAME = "space_missions";
    public static final String COLUMN_COMPANY = "company";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DATUM = "datum";
    public static final String COLUMN_DETAIL = "detail";
    public static final String COLUMN_STATUS_ROCKET = "status_rocket";
    public static final String COLUMN_STATUS_MISSION = "status_mission";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Space Missions");

        myDB = new MyDatabaseHelper(MainActivity.this);

        // check if table is empty. if so then fill the table from csv file
        if(validateIfTableHasData(myDB.getReadableDatabase(), TABLE_NAME)){
            Log.i("database", "table not empty");
        }else{
            Log.i("database", "table empty");
            readSpaceMissionsData();
        }
    }

    // checks if table is empty
    public boolean validateIfTableHasData(SQLiteDatabase myDatabase, String tableName){
        Cursor c = myDatabase.rawQuery("SELECT * FROM " + tableName,null);
        return c.moveToFirst();
    }

    // read data from space_missions.csv and insert into table
    private void readSpaceMissionsData() {
        SQLiteDatabase writableDB = myDB.getWritableDatabase();
        InputStream is = getResources().openRawResource(R.raw.space_missions_data);
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        String line = "";
        try{
            // step over the header
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // split by ','
                count += 1;
                String[] tokens = line.split(",");
                //Log.i(Integer.toString(count), tokens[0]);

                // insert row into table
                ContentValues cv = new ContentValues();
                cv.put(COLUMN_COMPANY, tokens[0]);
                cv.put(COLUMN_LOCATION, tokens[1]);
                cv.put(COLUMN_DATUM, tokens[2]);
                cv.put(COLUMN_DETAIL, tokens[3]);
                cv.put(COLUMN_STATUS_ROCKET, tokens[4]);
                cv.put(COLUMN_STATUS_MISSION, tokens[5]);

                long result = writableDB.insert(TABLE_NAME, null, cv);
                if(result == -1){
                    Log.i(Integer.toString(count), "failed");
                }else{
                    Log.i(Integer.toString(count), "success");
                }
            }

        } catch (IOException e){
            Log.i("reading csv file", "Error reading data file on line" + line, e);
        }
    }

    public void continueButtonListener(View v){
        startActivity(new Intent(MainActivity.this, SpaceCompanies.class));
    }
}
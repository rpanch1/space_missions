package com.example.spacemissions;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "space.db";
    public static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "space_missions";
    public static final String COLUMN_COMPANY = "company";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DATUM = "datum";
    public static final String COLUMN_DETAIL = "detail";
    public static final String COLUMN_STATUS_ROCKET = "status_rocket";
    public static final String COLUMN_STATUS_MISSION = "status_mission";

    public MyDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query =
                "CREATE TABLE " + TABLE_NAME +
                        " (" + COLUMN_COMPANY + " TEXT, " +
                        COLUMN_LOCATION + " TEXT, " +
                        COLUMN_DATUM + " TEXT, " +
                        COLUMN_DETAIL + " TEXT, " +
                        COLUMN_STATUS_ROCKET + " TEXT, " +
                        COLUMN_STATUS_MISSION + " TEXT);";
        db.execSQL(query);
        Log.i("database onCreate()", "table is created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // returns list of every company that has launched space mission
    public List<String> getCompanyNames(){
        List<String> returnList = new ArrayList<>();

        String query = "SELECT DISTINCT " + COLUMN_COMPANY + " FROM " + TABLE_NAME + " ORDER BY " + COLUMN_COMPANY;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){
            do{
                returnList.add(cursor.getString(0));
            }while(cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return returnList;
    }

    public List<MissionInfo> getMissions(String name){
        List<MissionInfo> returnList = new ArrayList<MissionInfo>();

        String query = "SELECT " + COLUMN_LOCATION + ", " + COLUMN_DATUM + ", " + COLUMN_DETAIL + ", " + COLUMN_STATUS_MISSION +
                " FROM " + TABLE_NAME + " WHERE " + COLUMN_COMPANY + "=" + "'" + name + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){
            do{
                MissionInfo mission = new MissionInfo(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3));
                returnList.add(mission);
            }while(cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return returnList;
    }
}

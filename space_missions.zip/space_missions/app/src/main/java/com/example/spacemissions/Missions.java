package com.example.spacemissions;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.List;
import java.util.Objects;

public class Missions extends AppCompatActivity {

    TextView missions_text, number;
    String name;

    MyDatabaseHelper myDB;
    ListView missions;
    List<MissionInfo> missionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_missions);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Space Missions");

        missions_text = (TextView) findViewById(R.id.missions_textview);
        missions = (ListView) findViewById(R.id.missions_listview);

        myDB = new MyDatabaseHelper(Missions.this);

        name = getIntent().getStringExtra("name");

        displayList();
    }

    private void displayList() {
        missionList = myDB.getMissions(name);
        missions_text.setText(String.format("%d %s Missions", missionList.size(), name));

        ArrayAdapter<MissionInfo> customArrayAdapter = new ArrayAdapter<MissionInfo>(Missions.this, android.R.layout.simple_list_item_1, missionList);
        missions.setAdapter(customArrayAdapter);

    }
}
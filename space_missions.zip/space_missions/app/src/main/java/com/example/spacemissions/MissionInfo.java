package com.example.spacemissions;

public class MissionInfo {
    String location;
    String datum;
    String detail;
    String status_mission;

    public MissionInfo(String _location, String _datum, String _detail, String _status_mission){
        location = _location;
        datum = _datum;
        detail = _detail;
        status_mission = _status_mission;
    }

    public String getLocation(){
        return location;
    }
    public String getDatum(){
        return datum;
    }
    public String getDetail(){
        return detail;
    }
    public String getStatusMission(){
        return status_mission;
    }

    @Override
    public String toString() {
        return '\n' + "Location: " + location + '\n' +
                "Datum: " + datum + '\n' +
                "Rocket: " + detail + '\n' +
                "Mission Status: " + status_mission + '\n';
    }
}

package com.example.spacemissions;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.List;
import java.util.Objects;

public class SpaceCompanies extends AppCompatActivity {

    MyDatabaseHelper myDB;
    ListView companies;
    List<String> companyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_space_companies);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Space Missions");

        companies = (ListView)findViewById(R.id.company_listview);

        myDB = new MyDatabaseHelper(SpaceCompanies.this);
        displayList();

        // listener for the list view in this activity
        companies.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(SpaceCompanies.this, Missions.class);
                intent.putExtra("name", companyList.get(i));
                startActivity(intent);
            }
        });
    }

    private void displayList() {
        companyList = myDB.getCompanyNames();

        ArrayAdapter<String> customArrayAdapter = new ArrayAdapter<String>(SpaceCompanies.this, android.R.layout.simple_list_item_1, companyList);
        companies.setAdapter(customArrayAdapter);
    }
}